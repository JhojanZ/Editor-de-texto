/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../EditorDeTexto/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_actionNuevo_triggered",
    "",
    "on_actionGuardar_triggered",
    "on_actionAbrir_triggered",
    "on_actionSalir_triggered",
    "on_actionExportar_triggered",
    "on_subrayar_clicked",
    "on_negrilla_clicked",
    "on_cursiva_clicked",
    "on_color_clicked",
    "on_tamano_clicked",
    "on_alineadoCentrado_clicked",
    "on_alineadoDerecha_clicked",
    "on_alineadoIzquierda_clicked",
    "on_alineadoJustificado_clicked",
    "on_tachado_clicked",
    "on_aumentarTamano_clicked",
    "on_disminuirTamano_clicked",
    "on_actionEliminar_triggered",
    "on_fuentes_currentFontChanged",
    "f",
    "on_imprimirPDF_clicked",
    "on_actionComandos_triggered",
    "on_actionAcerca_del_Auto_triggered"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[50];
    char stringdata0[11];
    char stringdata1[25];
    char stringdata2[1];
    char stringdata3[27];
    char stringdata4[25];
    char stringdata5[25];
    char stringdata6[28];
    char stringdata7[20];
    char stringdata8[20];
    char stringdata9[19];
    char stringdata10[17];
    char stringdata11[18];
    char stringdata12[28];
    char stringdata13[27];
    char stringdata14[29];
    char stringdata15[31];
    char stringdata16[19];
    char stringdata17[26];
    char stringdata18[27];
    char stringdata19[28];
    char stringdata20[30];
    char stringdata21[2];
    char stringdata22[23];
    char stringdata23[28];
    char stringdata24[35];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 24),  // "on_actionNuevo_triggered"
        QT_MOC_LITERAL(36, 0),  // ""
        QT_MOC_LITERAL(37, 26),  // "on_actionGuardar_triggered"
        QT_MOC_LITERAL(64, 24),  // "on_actionAbrir_triggered"
        QT_MOC_LITERAL(89, 24),  // "on_actionSalir_triggered"
        QT_MOC_LITERAL(114, 27),  // "on_actionExportar_triggered"
        QT_MOC_LITERAL(142, 19),  // "on_subrayar_clicked"
        QT_MOC_LITERAL(162, 19),  // "on_negrilla_clicked"
        QT_MOC_LITERAL(182, 18),  // "on_cursiva_clicked"
        QT_MOC_LITERAL(201, 16),  // "on_color_clicked"
        QT_MOC_LITERAL(218, 17),  // "on_tamano_clicked"
        QT_MOC_LITERAL(236, 27),  // "on_alineadoCentrado_clicked"
        QT_MOC_LITERAL(264, 26),  // "on_alineadoDerecha_clicked"
        QT_MOC_LITERAL(291, 28),  // "on_alineadoIzquierda_clicked"
        QT_MOC_LITERAL(320, 30),  // "on_alineadoJustificado_clicked"
        QT_MOC_LITERAL(351, 18),  // "on_tachado_clicked"
        QT_MOC_LITERAL(370, 25),  // "on_aumentarTamano_clicked"
        QT_MOC_LITERAL(396, 26),  // "on_disminuirTamano_clicked"
        QT_MOC_LITERAL(423, 27),  // "on_actionEliminar_triggered"
        QT_MOC_LITERAL(451, 29),  // "on_fuentes_currentFontChanged"
        QT_MOC_LITERAL(481, 1),  // "f"
        QT_MOC_LITERAL(483, 22),  // "on_imprimirPDF_clicked"
        QT_MOC_LITERAL(506, 27),  // "on_actionComandos_triggered"
        QT_MOC_LITERAL(534, 34)   // "on_actionAcerca_del_Auto_trig..."
    },
    "MainWindow",
    "on_actionNuevo_triggered",
    "",
    "on_actionGuardar_triggered",
    "on_actionAbrir_triggered",
    "on_actionSalir_triggered",
    "on_actionExportar_triggered",
    "on_subrayar_clicked",
    "on_negrilla_clicked",
    "on_cursiva_clicked",
    "on_color_clicked",
    "on_tamano_clicked",
    "on_alineadoCentrado_clicked",
    "on_alineadoDerecha_clicked",
    "on_alineadoIzquierda_clicked",
    "on_alineadoJustificado_clicked",
    "on_tachado_clicked",
    "on_aumentarTamano_clicked",
    "on_disminuirTamano_clicked",
    "on_actionEliminar_triggered",
    "on_fuentes_currentFontChanged",
    "f",
    "on_imprimirPDF_clicked",
    "on_actionComandos_triggered",
    "on_actionAcerca_del_Auto_triggered"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  146,    2, 0x08,    1 /* Private */,
       3,    0,  147,    2, 0x08,    2 /* Private */,
       4,    0,  148,    2, 0x08,    3 /* Private */,
       5,    0,  149,    2, 0x08,    4 /* Private */,
       6,    0,  150,    2, 0x08,    5 /* Private */,
       7,    0,  151,    2, 0x08,    6 /* Private */,
       8,    0,  152,    2, 0x08,    7 /* Private */,
       9,    0,  153,    2, 0x08,    8 /* Private */,
      10,    0,  154,    2, 0x08,    9 /* Private */,
      11,    0,  155,    2, 0x08,   10 /* Private */,
      12,    0,  156,    2, 0x08,   11 /* Private */,
      13,    0,  157,    2, 0x08,   12 /* Private */,
      14,    0,  158,    2, 0x08,   13 /* Private */,
      15,    0,  159,    2, 0x08,   14 /* Private */,
      16,    0,  160,    2, 0x08,   15 /* Private */,
      17,    0,  161,    2, 0x08,   16 /* Private */,
      18,    0,  162,    2, 0x08,   17 /* Private */,
      19,    0,  163,    2, 0x08,   18 /* Private */,
      20,    1,  164,    2, 0x08,   19 /* Private */,
      22,    0,  167,    2, 0x08,   21 /* Private */,
      23,    0,  168,    2, 0x08,   22 /* Private */,
      24,    0,  169,    2, 0x08,   23 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QFont,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_actionNuevo_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionGuardar_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAbrir_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionSalir_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionExportar_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_subrayar_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_negrilla_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_cursiva_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_color_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tamano_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_alineadoCentrado_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_alineadoDerecha_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_alineadoIzquierda_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_alineadoJustificado_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tachado_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_aumentarTamano_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_disminuirTamano_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionEliminar_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_fuentes_currentFontChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QFont &, std::false_type>,
        // method 'on_imprimirPDF_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionComandos_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAcerca_del_Auto_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_actionNuevo_triggered(); break;
        case 1: _t->on_actionGuardar_triggered(); break;
        case 2: _t->on_actionAbrir_triggered(); break;
        case 3: _t->on_actionSalir_triggered(); break;
        case 4: _t->on_actionExportar_triggered(); break;
        case 5: _t->on_subrayar_clicked(); break;
        case 6: _t->on_negrilla_clicked(); break;
        case 7: _t->on_cursiva_clicked(); break;
        case 8: _t->on_color_clicked(); break;
        case 9: _t->on_tamano_clicked(); break;
        case 10: _t->on_alineadoCentrado_clicked(); break;
        case 11: _t->on_alineadoDerecha_clicked(); break;
        case 12: _t->on_alineadoIzquierda_clicked(); break;
        case 13: _t->on_alineadoJustificado_clicked(); break;
        case 14: _t->on_tachado_clicked(); break;
        case 15: _t->on_aumentarTamano_clicked(); break;
        case 16: _t->on_disminuirTamano_clicked(); break;
        case 17: _t->on_actionEliminar_triggered(); break;
        case 18: _t->on_fuentes_currentFontChanged((*reinterpret_cast< std::add_pointer_t<QFont>>(_a[1]))); break;
        case 19: _t->on_imprimirPDF_clicked(); break;
        case 20: _t->on_actionComandos_triggered(); break;
        case 21: _t->on_actionAcerca_del_Auto_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
